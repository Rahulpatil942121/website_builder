<?php

namespace App\Http\Controllers\Client;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;
use Yoeunes\Toastr\Facades\Toastr;  
use App\Models\User;
use App\Models\Temptype;
use App\Models\Templatetb;
use App\Models\Temp_contain;
use App\Models\Usertemplatecontain;
use App\Models\Aboutus_tepmlate;
use App\Models\Domaincreation;
use App\Models\Contactus_template;
use Auth;
use DB;

class Clientcontroller extends Controller
{
    //

    public function index(Request $req)
    {
    	//dd($req);
    	 $validated = $req->validate([
            'login_id' => 'required|email',
            'password' => 'required',
        ]);
        $password = Hash::make($req->password);
       // dd($password);
        // $result1 = User::get();
        $userdata = array(
            'email'     => $req->login_id,
            'password'  => $req->password
        );         
        if(Auth::attempt($userdata))
        {
             // dd(Auth::User()->name);
            // dd(Auth::User()->role);
            // $req->session()->put('Admin_Login',true);
            // $req->session()->put('Admin_Id',Auth::User()->id);
            if(Auth::User()->status == 0 || Auth::User()->role != 2)
            {
            	 //dd(Auth::User()->name);
                //$req->session()->flash('alert-danger', 'Login ID Not Active!!');
                Toastr::error("Login ID Not Active!!");
                return redirect('/logout');
            }            

            //$data['flag'] = 1;

            Toastr::success("Hello ". Auth::User()->name);

            return redirect('/Home');            
        }
        else 
        {
            $req->session()->flash('alert-danger', 'Login ID Not Existing!!');
           // dd("Not Exsting");
           return back()->withInput();
        }
    }

    public function Homepage()
    {
    	//dd('hi');
        $data['flag'] = 1;
        $data['inline'] = 0;
        $data['Temptype'] = Temptype::where('status',1)->get();
        $data['client_template'] = Domaincreation::where('creater_id',Auth::User()->id)->get();        
        return view('/Frontend/Webviews/Manageviews',$data);
    }
    // public function Template_List()
    // {
    //     $data['flag'] = 2;
    //     $data['inline'] = 1;
    //     $data['title'] = "Template List";         
    //     return view('/Frontend/Webviews/Manageviews',$data); 
    // }

     public function Check_Template(Request $req)
     {
        //dd($req);

            $this->validate($req,[                 
                'temp_type'=>'required|numeric',                          
             ]);             

        $data['flag'] = 2;
        $data['inline'] = 0;
        $data['title'] = "Templates";
        if($req->temp_type == 0)
        {
            $data['Templatetb'] = Templatetb::where(['status'=>1])->orderBy('temp_type','asc')->get();
        }
        else
        {
            $data['Templatetb'] = Templatetb::where(['status'=>1,'temp_type'=>$req->temp_type])->orderBy('temp_type','asc')->get();  
        }                
        return view('/Frontend/Webviews/Manageviews',$data);
     }
// -------------------------------------
     public function Add_Template_Data($template_id)
     {
        if(DB::table('templatetbs')->where(['id'=>$template_id,'status'=>1])->exists())
        {
            $data['flag'] = 3;
            $data['inline'] = 0;
            $data['title'] = "Templates Data";
            $data['template_id'] = $template_id;
            $data['Contain'] = Temp_contain::where('temp_id',$template_id)->get();
            return view('/Frontend/Webviews/Manageviews',$data);
        }
        else
        {
            Toastr::error("Template Not Exsting!!");
            return redirect('/Home');
        }
     }

     // --------------------------------------

     public function Submit_Aboutus_Data(Request $req)
     {
        //dd($req);

        $this->validate($req,[
                'temp_id'=>'required',
                'about_heading'=>'required', 
                'aboutus_description'=>'required',
                'aboutus_img'=>'nullable|image|mimes:png',                          
             ]);

         $image = "";
         $ap_image = "";

         $this->checktemplate_InClient($req->temp_id);
         dd("Hi");
         if($req->has('aboutus_img'))
         {
             $file = $req->file('aboutus_img');
           // dd($file);
            $filename = 'aboutus'.time().'.'.$file->extension();
            $destinationPath = public_path('/images/Aboutus');       
            $ap_image = $_SERVER['SERVER_NAME'].'/public/images/Aboutus/'.$filename;
            $image = 'images/Aboutus/'.$filename;

         } 


            $data = new Usertemplatecontain;
            $data->temp_id=$req->temp_id;
            $data->creater_id =Auth::User()->id;
            $data->conatin_id =3;
            $data->save();

            $data = new Aboutus_tepmlate;
            $data->temp_id =$req->temp_id;
            $data->creater_id =Auth::User()->id;
            $data->heading=$req->about_heading;
            $data->about_description=$req->aboutus_description;                 
            $data->apimage=$ap_image; 
            $data->image=$image;                           
            $result = $data->save();

            if($result && $req->has('aboutus_img'))
           {
              $file->move($destinationPath, $filename);
           } 
        if($result)
        {           
            Toastr::success("Aboutus Data Inserted Successfully!!!"); 
        }
        else
        {
            Toastr::error("Aboutus Data Not Inserted!!!");
        }

        return back(); 
     }

     // --------------------------------------------

     public function checktemplate_InClient($temp_id)
     {
        //dd($temp_id);

       if(DB::table('domaincreations')->where(['temp_id'=>$temp_id,'creater_id'=>Auth::User()->id])->doesntExist())
        {
               start:

            $chars = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
            $doimain = substr(str_shuffle($chars),0,20);
            //$doimain = random_strings(15);
            //dd($doimain);
             if(DB::table('domaincreations')->where(['domain_name'=>$doimain])->exists())
            {
                goto start;
            }    

            $datatb = new Domaincreation;
            $datatb->domain_name=$doimain; 
            $datatb->temp_id=$temp_id;                 
            $datatb->creater_id=Auth::User()->id;
            $datatb->role=Auth::User()->role;                 
            $datatb->status=0;                           
            $datatb->save();
        }  

        
     }


     // ----------------------------------------

     public function Submit_Contact_Data(Request $req)
     {        

         $this->validate($req,[
                'temp_id'=>'required',
                'contact_email'=>'required|email', 
                'contact_phone'=>'required|digits:10|numeric',
                'contact_otherfields'=>'nullable',
                'contact_address'=>'required',                          
             ]);

            $this->checktemplate_InClient($req->temp_id);

            $data = new Usertemplatecontain;
            $data->temp_id=$req->temp_id;
            $data->creater_id =Auth::User()->id;
            $data->conatin_id =4;
            $data->save();

            $data = new Contactus_template;
            $data->temp_id =$req->temp_id;
            $data->creater_id =Auth::User()->id;
            $data->contact_email=$req->contact_email;
            $data->contact_phone=$req->contact_phone;                 
            $data->contact_otherfields=$req->contact_otherfields; 
            $data->contact_address=$req->contact_address;                           
            $result = $data->save();

        if($result)
        {             
            Toastr::success("Contact Us Inserted Successfully!!!"); 
        }
        else
        {
            Toastr::error("Contact Us Not Inserted!!!");
        }

        return back(); 


        //dd($req);
     }
}
